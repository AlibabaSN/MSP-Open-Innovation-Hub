# MSP Open Innovation Hub

A full‑stack web application for MSPs and IT teams to propose, discuss, and prioritize innovative ideas that improve MSP business and internal IT operations.

## Features
- Email/password auth with JWT
- Roles: admin, member
- Submit ideas, comment, upvote, tag, and track status
- Search & filter
- Secure REST API
- PostgreSQL database
- Docker Compose for one‑command setup

## Quick Start (Docker)
```bash
# 1) copy env files
cp api/.env.example api/.env
# 2) run everything
docker compose up --build
# Web: http://localhost:5173
# API: http://localhost:4000
# PgAdmin: http://localhost:5050 (optional)
```

## Manual Start (no Docker)
- Install Postgres locally and create a DB `msp_innovation`.
- `cd api && cp .env.example .env && npm i && npm run migrate && npm run dev`
- `cd web && npm i && npm run dev`

## Default accounts (seeded)
- admin@example.com / admin123 (role: admin)
- user@example.com / user123 (role: member)

## API Overview
- `POST /auth/register` — create account
- `POST /auth/login` — login to get token
- `GET /me` — current user (auth)
- `GET /ideas` — list ideas (public)
- `POST /ideas` — create idea (auth)
- `POST /ideas/:id/vote` — upvote/downvote (auth)
- `POST /ideas/:id/comments` — add comment (auth)
- `PATCH /ideas/:id/status` — update status (admin)

See `api/src/routes/*.js`.

## Derived From Image (extracted text)
**Open Innovation** — Explore and innovate beyond preset themes, including:
- Any other impactful aspects of the MSP business or internal IT operations
- Unique, creative ideas that drive value for MSPs and IT teams
```
This project operationalizes that brief into a working app.
```


## New features added in this Complete Build
- Kanban-style workflow board to visualize ideas by status (proposed, in_review, planned, done, rejected)
- Admin panel to change idea status and manage users
- Improved frontend UX (search, voting feedback, client-side validation)
- API response error handling in the frontend
- Better seed data for demo

## How to run (same as before)
1. `cp api/.env.example api/.env`
2. `docker compose up --build`
3. Visit the web UI and login as admin or user.


Included UI mock screenshots: mock_screens/*.png

## Deploying (Railway backend + Vercel frontend)

### Backend (Railway)
1. Push the `api/` folder to a Git repo used by Railway.
2. Create a Railway project, link your repo, and set the environment variables:
   - `DATABASE_URL` (Railway Postgres URL)
   - `JWT_SECRET`
3. Railway will detect the Node app and run `npm install` and `npm start` (Procfile included).

### Frontend (Vercel)
1. Push the `web/` folder to a Git repo used by Vercel (root or separate).
2. In Vercel create a new project, point it to the repo, and set build command: `npm run build` and output dir `dist`.
3. Set environment variable `VITE_API_URL` to your Railway backend URL.


## CI/CD (GitHub Actions)

The repository includes a GitHub Actions workflow at `.github/workflows/ci.yml` which:
- Spins up Postgres to run backend migrations and tests.
- Runs frontend tests (Vitest).
- Builds the frontend.
- Deploys to Railway and Vercel on pushes to `main` (requires secrets configured).

### Required GitHub Secrets
- `RAILWAY_API_KEY`
- `RAILWAY_PROJECT_ID`
- `VERCEL_TOKEN`
- `VERCEL_ORG_ID`
- `VERCEL_PROJECT_ID`
- `DATABASE_URL` (for manual runs or other actions)
- `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_CALLBACK_URL`
- `GITHUB_CLIENT_ID`, `GITHUB_CLIENT_SECRET`, `GITHUB_CALLBACK_URL`
- `SESSION_SECRET`

## OAuth Setup (Google & GitHub)

1. Create OAuth apps:
   - Google: https://console.developers.google.com
     - Authorized redirect URI: `https://<your-backend>/auth/google/callback` or `http://localhost:4000/auth/google/callback`
   - GitHub: https://github.com/settings/developers
     - Authorization callback URL: `https://<your-backend>/auth/github/callback` or `http://localhost:4000/auth/github/callback`

2. Set the following environment variables in Railway / GitHub Actions / .env:
   - `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_CALLBACK_URL`
   - `GITHUB_CLIENT_ID`, `GITHUB_CLIENT_SECRET`, `GITHUB_CALLBACK_URL`
   - `SESSION_SECRET`

3. On successful OAuth sign-in users are redirected to the frontend URL defined in `FRONTEND_URL` env var.

