import express from 'express';
import passport from '../auth/oauth.js';
const router = express.Router();

router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));
router.get('/google/callback', passport.authenticate('google', { failureRedirect: '/' }), (req,res) => {
  // successful auth
  res.redirect(process.env.FRONTEND_URL || 'http://localhost:5173');
});

router.get('/github', passport.authenticate('github', { scope: ['user:email'] }));
router.get('/github/callback', passport.authenticate('github', { failureRedirect: '/' }), (req,res) => {
  res.redirect(process.env.FRONTEND_URL || 'http://localhost:5173');
});

router.get('/logout', (req,res) => {
  req.logout(()=>{});
  res.json({ ok:true });
});

export default router;
