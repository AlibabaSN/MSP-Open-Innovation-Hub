import express from 'express';
import { query } from '../db/client.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';

const router = express.Router();

router.get('/users', requireAuth, requireAdmin, async (req,res)=>{
  const r = await query("SELECT id,email,name,role,created_at FROM users ORDER BY id");
  res.json(r.rows);
});

router.post('/users/:id/role', requireAuth, requireAdmin, async (req,res)=>{
  const id = Number(req.params.id);
  const { role } = req.body;
  const r = await query("UPDATE users SET role=$1 WHERE id=$2 RETURNING id,email,name,role", [role, id]);
  res.json(r.rows[0]);
});

export default router;
