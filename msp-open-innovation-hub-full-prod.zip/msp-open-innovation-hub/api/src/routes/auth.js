import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { query } from '../db/client.js';

const router = express.Router();

router.post('/register', async (req,res)=>{
  const { email, password, name } = req.body;
  if(!email || !password || !name) return res.status(400).json({error:'missing_fields'});
  const hash = await bcrypt.hash(password, 10);
  try{
    const result = await query("INSERT INTO users(email,password_hash,name) VALUES($1,$2,$3) RETURNING id,email,name,role", [email, hash, name]);
    const user = result.rows[0];
    const token = jwt.sign(user, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user });
  }catch(e){
    res.status(400).json({error:'email_taken'});
  }
});

router.post('/login', async (req,res)=>{
  const { email, password } = req.body;
  const result = await query("SELECT id,email,password_hash,name,role FROM users WHERE email=$1", [email]);
  const user = result.rows[0];
  if(!user) return res.status(401).json({error:'invalid_credentials'});
  const ok = await bcrypt.compare(password, user.password_hash);
  if(!ok) return res.status(401).json({error:'invalid_credentials'});
  delete user.password_hash;
  const token = jwt.sign(user, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user });
});

export default router;
