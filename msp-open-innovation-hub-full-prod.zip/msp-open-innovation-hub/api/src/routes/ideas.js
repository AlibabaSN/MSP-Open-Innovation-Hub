import express from 'express';
import { query } from '../db/client.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';

const router = express.Router();

router.get('/', async (req,res)=>{
  const q = req.query.q?.trim();
  let sql = "SELECT i.*, COALESCE(SUM(v.value),0) as score FROM ideas i LEFT JOIN votes v ON i.id=v.idea_id";
  const params = [];
  if(q){ sql += " WHERE i.title ILIKE $1 OR i.description ILIKE $1"; params.push('%'+q+'%'); }
  sql += " GROUP BY i.id ORDER BY score DESC, created_at DESC";
  const result = await query(sql, params);
  res.json(result.rows);
});

router.post('/', requireAuth, async (req,res)=>{
  const { title, description, tags } = req.body;
  const result = await query(
    "INSERT INTO ideas(user_id,title,description,tags) VALUES($1,$2,$3,$4) RETURNING *",
    [req.user.id, title, description, tags || []]
  );
  res.status(201).json(result.rows[0]);
});

router.post('/:id/vote', requireAuth, async (req,res)=>{
  const { value } = req.body; // 1 or -1
  const id = Number(req.params.id);
  await query(`INSERT INTO votes(idea_id,user_id,value)
               VALUES($1,$2,$3)
               ON CONFLICT (idea_id,user_id) DO UPDATE SET value=EXCLUDED.value`, [id, req.user.id, value]);
  const score = await query("SELECT COALESCE(SUM(value),0) AS score FROM votes WHERE idea_id=$1",[id]);
  res.json({ ok:true, score: score.rows[0].score });
});

router.post('/:id/comments', requireAuth, async (req,res)=>{
  const id = Number(req.params.id);
  const { body } = req.body;
  const r = await query("INSERT INTO comments(idea_id,user_id,body) VALUES($1,$2,$3) RETURNING *",
    [id, req.user.id, body]);
  res.status(201).json(r.rows[0]);
});

router.patch('/:id/status', requireAuth, requireAdmin, async (req,res)=>{
  const id = Number(req.params.id);
  const { status } = req.body; // proposed, in_review, planned, done, rejected
  const r = await query("UPDATE ideas SET status=$1, updated_at=now() WHERE id=$2 RETURNING *", [status, id]);
  res.json(r.rows[0]);
});

export default router;
