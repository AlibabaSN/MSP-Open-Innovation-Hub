import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import { Strategy as GitHubStrategy } from 'passport-github2';
import { query } from '../db/client.js';
import dotenv from 'dotenv';
dotenv.config();

function findOrCreateUser(provider, profile, cb){
  (async ()=>{
    try {
      const email = profile.emails && profile.emails[0] && profile.emails[0].value;
      const oauthId = profile.id;
      const existing = await query('SELECT * FROM users WHERE oauth_provider=$1 AND oauth_id=$2', [provider, oauthId]);
      if(existing.rows[0]) return cb(null, existing.rows[0]);
      // create user
      const name = profile.displayName || (email || 'User');
      const r = await query('INSERT INTO users(email,name,oauth_provider,oauth_id) VALUES($1,$2,$3,$4) RETURNING *', [email, name, provider, oauthId]);
      return cb(null, r.rows[0]);
    } catch (e) { return cb(e); }
  })();
}

if(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET){
  passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: process.env.GOOGLE_CALLBACK_URL || '/auth/google/callback'
  }, (accessToken, refreshToken, profile, done) => {
    findOrCreateUser('google', profile, done);
  }));
}

if(process.env.GITHUB_CLIENT_ID && process.env.GITHUB_CLIENT_SECRET){
  passport.use(new GitHubStrategy({
    clientID: process.env.GITHUB_CLIENT_ID,
    clientSecret: process.env.GITHUB_CLIENT_SECRET,
    callbackURL: process.env.GITHUB_CALLBACK_URL || '/auth/github/callback',
    scope: ['user:email']
  }, (accessToken, refreshToken, profile, done) => {
    findOrCreateUser('github', profile, done);
  }));
}

export default passport;
