import { query } from './client.js';
import bcrypt from 'bcryptjs';

async function seed(){
  const adminPass = await bcrypt.hash('admin123', 10);
  const userPass = await bcrypt.hash('user123', 10);
  await query("INSERT INTO users(email,password_hash,name,role) VALUES($1,$2,$3,$4) ON CONFLICT (email) DO NOTHING",[ 'admin@example.com', adminPass, 'Admin', 'admin' ]);
  await query("INSERT INTO users(email,password_hash,name,role) VALUES($1,$2,$3,$4) ON CONFLICT (email) DO NOTHING",[ 'user@example.com', userPass, 'User', 'member' ]);

  await query("INSERT INTO ideas(user_id,title,description,tags,status) VALUES(2,$1,$2,$3,'proposed') ON CONFLICT DO NOTHING",
    ['AI-driven ticket triage', 'Use NLP to auto-categorize and route tickets to reduce SLA breaches.', ['ai','ops']]);
  await query("INSERT INTO ideas(user_id,title,description,tags,status) VALUES(2,$1,$2,$3,'in_review') ON CONFLICT DO NOTHING",
    ['Self-healing scripts', 'Automated remediation for recurring incidents to lower manual effort.', ['automation','devops']]);
  await query("INSERT INTO ideas(user_id,title,description,tags,status) VALUES(2,$1,$2,$3,'planned') ON CONFLICT DO NOTHING",
    ['Knowledge base auto-suggestions', 'Recommend KB articles to agents while typing replies.', ['ai','kb']]);
  await query("INSERT INTO ideas(user_id,title,description,tags,status) VALUES(2,$1,$2,$3,'done') ON CONFLICT DO NOTHING",
    ['Password rotation tooling', 'Centralized tooling for password rotation across services.', ['security']]);
  await query("INSERT INTO ideas(user_id,title,description,tags,status) VALUES(2,$1,$2,$3,'rejected') ON CONFLICT DO NOTHING",
    ['Manual reporting', 'Replace with automated dashboards (rejected as low value).', ['reports']]);

  console.log('Seed complete');
  process.exit(0);
}
seed();
