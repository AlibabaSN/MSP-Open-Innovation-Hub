import knex from 'knex';
import dotenv from 'dotenv';
dotenv.config();
const k = knex({
  client: 'pg',
  connection: process.env.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/msp_innovation',
  pool: { min: 2, max: 10 }
});
export default k;
