import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import { requireAuth } from './middleware/auth.js';
import authRoutes from './routes/auth.js';
import ideasRoutes from './routes/ideas.js';
import adminRoutes from './routes/admin.js';
import oauthRoutes from './routes/oauth.js';
import { query } from './db/client.js';

dotenv.config();
const app = express();
app.use(helmet());
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());

import session from 'express-session';
import pgSession from 'connect-pg-simple';
import passport from 'passport';
import dotenv from 'dotenv';
dotenv.config();

const PgSession = pgSession(session);
app.use(session({
  store: new (PgSession)({
    pool: null,
    conString: process.env.DATABASE_URL
  }),
  secret: process.env.SESSION_SECRET || process.env.JWT_SECRET || 'sessionsecret',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 30 * 24 * 60 * 60 * 1000 } // 30 days
}));

app.use(passport.initialize());
app.use(passport.session());


app.get('/', (_,res)=> res.json({ ok:true, name:'MSP Open Innovation API' }));
app.use('/auth', authRoutes);
app.get('/me', requireAuth, (req,res)=> res.json(req.user));
app.use('/ideas', ideasRoutes);
app.use('/admin', adminRoutes);
app.use('/auth', oauthRoutes);

// health

passport.serializeUser((user, done) => {
  done(null, user.id);
});
passport.deserializeUser(async (id, done) => {
  try {
    const r = await query('SELECT id,email,name,role,oauth_provider,oauth_id FROM users WHERE id=$1', [id]);
    done(null, r.rows[0]);
  } catch (e) { done(e); }
});

app.get('/healthz', async (_,res)=> {
  await query('SELECT 1');
  res.json({ok:true});
});

const port = process.env.PORT || 4000;
app.listen(port, ()=> console.log('API listening on', port));
