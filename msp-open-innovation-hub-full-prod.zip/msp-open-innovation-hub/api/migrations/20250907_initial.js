/**
 * initial migration - create users, ideas, votes, comments
 */
export async function up(knex) {
  await knex.schema.createTable('users', (t) => {
    t.increments('id').primary();
    t.string('email').unique().nullable();
    t.string('password_hash').nullable();
    t.string('name').notNullable();
    t.string('role').notNullable().defaultTo('member');
    t.string('oauth_provider').nullable();
    t.string('oauth_id').nullable();
    t.timestamps(true, true);
  });

  await knex.schema.createTable('ideas', (t) => {
    t.increments('id').primary();
    t.integer('user_id').references('id').inTable('users').onDelete('SET NULL');
    t.string('title').notNullable();
    t.text('description').notNullable();
    t.specificType('tags', 'text[]');
    t.string('status').notNullable().defaultTo('proposed');
    t.timestamps(true, true);
  });

  await knex.schema.createTable('votes', (t) => {
    t.increments('id').primary();
    t.integer('idea_id').references('id').inTable('ideas').onDelete('CASCADE');
    t.integer('user_id').references('id').inTable('users').onDelete('CASCADE');
    t.integer('value').notNullable();
    t.unique(['idea_id','user_id']);
  });

  await knex.schema.createTable('comments', (t) => {
    t.increments('id').primary();
    t.integer('idea_id').references('id').inTable('ideas').onDelete('CASCADE');
    t.integer('user_id').references('id').inTable('users').onDelete('SET NULL');
    t.text('body').notNullable();
    t.timestamps(true, true);
  });
}

export async function down(knex) {
  await knex.schema.dropTableIfExists('comments');
  await knex.schema.dropTableIfExists('votes');
  await knex.schema.dropTableIfExists('ideas');
  await knex.schema.dropTableIfExists('users');
}
