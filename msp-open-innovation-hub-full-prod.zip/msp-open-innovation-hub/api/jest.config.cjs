module.exports = {
  testEnvironment: 'node',
};