import { render, screen } from '@testing-library/react'
import App from '../App.jsx'

test('renders app title', () => {
  render(<App />)
  const el = screen.getByText(/MSP Open Innovation Hub/i)
  expect(el).toBeInTheDocument()
})
