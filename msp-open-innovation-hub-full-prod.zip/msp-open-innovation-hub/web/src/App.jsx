import React, { useEffect, useState } from 'react'
import './styles.css'
import { Login, Register } from './auth.jsx'
import { api, setToken, getToken } from './api.js'
import KanbanBoard from './KanbanBoard.jsx'
import AdminPanel from './AdminPanel.jsx'

export default function App(){
  const [user,setUser] = useState(null)
  const [ideas,setIdeas] = useState([])
  const [q,setQ] = useState('')
  const [view, setView] = useState('list')

  useEffect(()=>{
    const t = getToken()
    if(t) api.get('/me').then(r=> setUser(r.data)).catch(()=>{ setToken(null); setUser(null) })
    loadIdeas()
  },[])

  async function loadIdeas(search){
    const r = await api.get('/ideas', { params: { q: search || q } })
    setIdeas(r.data)
  }
  async function createIdea(e){
    e.preventDefault()
    const title = e.target.title.value
    const description = e.target.description.value
    const tags = e.target.tags.value.split(',').map(t=>t.trim()).filter(Boolean)
    try{
      const r = await api.post('/ideas', { title, description, tags })
      setIdeas([r.data, ...ideas])
      e.target.reset()
      setView('list')
    }catch(e){ alert('Failed to create idea: '+(e.response?.data?.error || e.message)) }
  }
  async function vote(id, value){
    try{
      await api.post(`/ideas/${id}/vote`, { value })
      loadIdeas()
    }catch(e){ alert('Vote failed') }
  }

  return (
    <div className="container mx-auto p-6 max-w-5xl">
      <header className="flex justify-between items-center mb-6">
        <div>
          <h1 style={{margin:0}}>MSP Open Innovation Hub</h1>
          <div className="small">Collaborative idea intake & prioritization for MSPs</div>
        </div>
        <div className="row">
          {user ? <div className="user-badge">{user.name}</div> : null}
          <nav>
            <button className="button" onClick={()=> setView('list')}>Ideas</button>
            <button className="button" style={{marginLeft:8}} onClick={()=> setView('kanban')}>Kanban</button>
            {user?.role === 'admin' && <button className="button" style={{marginLeft:8}} onClick={()=> setView('admin')}>Admin</button>}
          </nav>
        </div>
      </header>

      {view === 'list' && <div>
      <div style={{display:'flex',gap:12, marginBottom:12}}>
        <input className="input" value={q} onChange={e=> setQ(e.target.value)} placeholder="Search ideas…" />
        <button className="button" onClick={()=> loadIdeas()}>Search</button>
      </div>

      <div style={{display:'flex',gap:12}}>
        <div style={{flex:2}}>
          <div className="grid">
            {ideas.map(i => (
              <div key={i.id} className="card idea-card">
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                  <h3 style={{margin:0}}>{i.title}</h3>
                  <div className="small">Score: <strong>{i.score}</strong></div>
                </div>
                <div className="small">{i.description}</div>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                  <div className="small">Status: {i.status}</div>
                  <div>
                    <button className="button" onClick={()=> vote(i.id,1)}>Up</button>
                    <button className="button" style={{marginLeft:8}} onClick={()=> vote(i.id,-1)}>Down</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <aside style={{flex:1}}>
          <div className="card">
            {user ? (
              <div>
                <h4 style={{marginTop:0}}>Submit Idea</h4>
                <form onSubmit={createIdea} style={{display:'grid',gap:8}}>
                  <input className="input" name="title" placeholder="Title" required />
                  <textarea className="input" name="description" placeholder="Describe the innovation..." required rows="4" />
                  <input className="input" name="tags" placeholder="tags comma separated (e.g., ai, ops)" />
                  <button className="button" type="submit">Submit</button>
                </form>
              </div>
            ) : (
              <div>
                <h4>Get started</h4>
                <div className="small">Login or register to submit and vote on ideas.</div>
                <div style={{marginTop:12}}>
                  <Login onLogin={setUser} />
                </div>
              </div>
            )}
          </div>
        </aside>
      </div>
      </div>}

      {view === 'kanban' && <KanbanBoard />}

      {view === 'admin' && user?.role === 'admin' && <AdminPanel />}

      <footer className="footer">Built for MSPs — Open Innovation Hub</footer>
    </div>
  )
}
