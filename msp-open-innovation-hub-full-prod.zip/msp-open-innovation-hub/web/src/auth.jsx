import React from 'react'
import { api, setToken } from './api.js'

export function Login({ onLogin }){
  async function submit(e){
    e.preventDefault()
    const { email, password } = e.target
    const r = await api.post('/auth/login', { email: email.value, password: password.value })
    setToken(r.data.token)
    onLogin(r.data.user)
  }
  return (
    <form onSubmit={submit} style={{display:'grid', gap:8}}>
      <h3>Login</h3>
      <input name="email" placeholder="Email" type="email" required />
      <input name="password" placeholder="Password" type="password" required />
      <button type="submit">Login</button>
    </form>

<div style={{marginTop:12}}>
  <div style={{margin:'8px 0'}}>Or sign in with</div>
  <div style={{display:'flex',gap:8}}>
    <a className="button" href={import.meta.env.VITE_API_URL ? import.meta.env.VITE_API_URL + '/auth/google' : 'http://localhost:4000/auth/google'}>Login with Google</a>
    <a className="button" style={{marginLeft:8}} href={import.meta.env.VITE_API_URL ? import.meta.env.VITE_API_URL + '/auth/github' : 'http://localhost:4000/auth/github'}>Login with GitHub</a>
  </div>
</div>
  )
}

export function Register({ onRegister }){
  async function submit(e){
    e.preventDefault()
    const { name, email, password } = e.target
    const r = await api.post('/auth/register', { name: name.value, email: email.value, password: password.value })
    setToken(r.data.token)
    onRegister(r.data.user)
  }
  return (
    <form onSubmit={submit} style={{display:'grid', gap:8}}>
      <h3>Register</h3>
      <input name="name" placeholder="Name" required />
      <input name="email" placeholder="Email" type="email" required />
      <input name="password" placeholder="Password" type="password" required />
      <button type="submit">Register</button>
    </form>

<div style={{marginTop:12}}>
  <div style={{margin:'8px 0'}}>Or sign in with</div>
  <div style={{display:'flex',gap:8}}>
    <a className="button" href={import.meta.env.VITE_API_URL ? import.meta.env.VITE_API_URL + '/auth/google' : 'http://localhost:4000/auth/google'}>Login with Google</a>
    <a className="button" style={{marginLeft:8}} href={import.meta.env.VITE_API_URL ? import.meta.env.VITE_API_URL + '/auth/github' : 'http://localhost:4000/auth/github'}>Login with GitHub</a>
  </div>
</div>
  )
}
