import React, { useEffect, useState } from 'react'
import { api } from './api.js'
const STATUSES = ['proposed','in_review','planned','done']

export default function KanbanBoard(){
  const [ideas, setIdeas] = useState([])
  useEffect(()=> { load() }, [])
  async function load(){ const r = await api.get('/ideas'); setIdeas(r.data) }

  function byStatus(status){ return ideas.filter(i => i.status === status) }

  async function move(id, status){
    await api.patch(`/ideas/${id}/status`, { status }).catch(e=> alert('Failed: '+(e.response?.data?.error || e.message)))
    load()
  }

  return (
    <div>
      <h2>Kanban Board</h2>
      <div className="kboard">
        {STATUSES.map(s=> (
          <div key={s} className="kcol card">
            <h4 style={{textTransform:'capitalize'}}>{s}</h4>
            {byStatus(s).map(i => (
              <div key={i.id} className="card" style={{marginTop:8}}>
                <strong>{i.title}</strong>
                <div className="small">{i.description}</div>
                <div style={{marginTop:8}}>
                  {STATUSES.filter(x=>x!==s).map(target=> (
                    <button key={target} className="button" style={{marginRight:6}} onClick={()=> move(i.id, target)}>{target}</button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}
