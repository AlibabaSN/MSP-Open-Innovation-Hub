import React, { useEffect, useState } from 'react'
import { api } from './api.js'

export default function AdminPanel(){
  const [users, setUsers] = useState([])
  useEffect(()=> { load() }, [])
  async function load(){
    const r = await api.get('/admin/users').catch(()=> ({data:[]}))
    setUsers(r.data || [])
  }
  async function toggleRole(u){
    await api.post(`/admin/users/${u.id}/role`, { role: u.role === 'admin' ? 'member' : 'admin' }).catch(e=> alert('Error'))
    load()
  }
  return (
    <div>
      <h2>Admin Panel</h2>
      <div className="card">
        <h3>Users</h3>
        <table style={{width:'100%'}}>
          <thead><tr><th>Email</th><th>Name</th><th>Role</th><th>Action</th></tr></thead>
          <tbody>
            {users.map(u=> (
              <tr key={u.id}><td>{u.email}</td><td>{u.name}</td><td>{u.role}</td><td><button className="button" onClick={()=> toggleRole(u)}>Toggle Role</button></td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
